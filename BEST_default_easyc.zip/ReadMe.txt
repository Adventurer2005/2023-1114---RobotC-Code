BEST Robotics Default EasyC Program for 2015

This program has reduced functionality from previous years,
to encourage teams to write their own better code.

Controller summary:
 Arcade drive on right joystick (1,2) to motor ports 2(right) and 9(left motor)
 Analog motor/servo from left joystick up/dn channel 3 to motor port 5
 Analog motor/servo from left joystick L/R  channel 4 to motor port 6

Global definitions for common buttons/sticks/motors have been defined as aliases.
You don't have to use them, but it is easier to understand:
 with Global constants: Arcade2( Joy1, Stk2, Stk1, M9, M2, NoInvert, NoInvert );
 with just numbers like this, Arcade2( 1, 2, 1, 9, 2, 0, 0);
  its harder to remember order of the parameters.