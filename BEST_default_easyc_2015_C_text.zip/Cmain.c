#include "Main.h"

void Cmain ( void ) {
    #define GJD( btn, udlr )     GetJoystickDigital( Joy1, btn, udlr)
    #define GDI( X )             GetDigitalInput( X )
    for ( i= Stk1;  i <= Stk4; i++ )  {  SetJoystickAnalogDeadband( Joy1, i , 6, 6 ) ; } ;
    AA = 1 ;
    while ( 1 ) { // repeats forever
        // Arcade parms: 1, F/B stick, L/R stick,  Left wheel motor, Right wheel motor  
        Arcade2 ( Joy1 , Stk2 , Stk1 , M2 , M9 , 0 , NoInvert ) ; // Ch2 is forward/reverse and Ch1 is rotate left/right: Basically the right stick is a normal joystick
        //JoystickToMotor ( Joy1 , Stk1 , M2 , NoInvert ) ; 
        JoystickToServo ( Joy1, Stk3, M5 , 0 ) ; // Motor in port 5 controlled by Joystick channel 3 (Left  updown stick)
        JoystickToMotor ( Joy1, Stk4, M6 , NoInvert ) ; // Motor in port 6 controlled by Joystick channel 4 (Left  right/left stick)
        JoystickDigitalToMotor ( Joy1 , B7 , Up   , 100 , Down  , -100 , M4 ) ;
        JoystickDigitalToMotor ( Joy1 , B7 , Left , 127 , Right , -127 , M8 ) ;
      } // END REPEAT FOREVER
} // End C-code for Cmain


