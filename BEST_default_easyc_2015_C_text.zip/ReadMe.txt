BEST Robotics  multi-program for Summer training in Denver 2018

WITHOUT JUMPERS, it acts like 2015+ default program
    This program has reduced functionality from previous years,
    to encourage teams to write their own better code.

    Controller summary:
     Arcade drive on right joystick (1,2) to motor ports 2(right) and 9(left motor)
     Analog motor/servo from left joystick up/dn channel 3 to motor port 5
     Analog motor/servo from left joystick L/R  channel 4 to motor port 6

WITH JUMPER 12, it does only tank drive, for comparison to arcade

WITH JUMPER 11, it does handcoded gearshift arcade
    B7 up,left,down,right snifts to speed divided by 1,1.5,2,2.5 = fast to slow

WITH JUMPER 10, it uses the Eboard program: 
    Jumper 1,2,3,4 Digital Inputs are also used as Limit Switches
    Tank drive eqv,
    Arm radial and sliders with limit switches
     Button control B7 Up/Dn, B8 L/R,
    Servos slaved to Motor ports, including limit switches

WITH ANY of JUMPER 9
   It demonstrates multiple motor assignment jitter

WITH ANY of JUMPER 8
   It allows testing every joystick button, each does motor action

JUMPERS/LIMIT SWITCHES 1,2,3,4 are Limit switches for E board mode

Global definitions for common buttons/sticks/motors have been defined as aliases.
You don't have to use them, but it is easier to understand:
 with Global constants: Arcade2( Joy1, Stk2, Stk1, M9, M2, NoInvert, NoInvert );
 with just numbers like this, Arcade2( 1, 2, 1, 9, 2, 0, 0);
  its harder to remember order of the parameters.

Some macros #defined to abbreviations:  GJD(a,b) instead of GetJoyStickDigital(Joy1, a,b)

Some IF/THEN/ELSE code has been compacted with 'trinary' 
Trinary is( condition      ? do this if true : do this if false )
Example:  ( GJD(B7,Up) ==1 ? Speed_div = 1   : null); // ( null is zero, doesn't change Speed_div)

Trinary can also return a value:
 SetMotor( M7, ( condition ? 64 : 0 ) ); // Set Motor to either 64 or 0 depending on condition

Trinary can also be stacked like If Then Else, but only with UserCode for every line
 IF A THEN B ELSEIF C THEN D ELSE E 
  A ? B
: C ? D
:     E





